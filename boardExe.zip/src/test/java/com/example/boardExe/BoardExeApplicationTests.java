package com.example.boardExe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoardExeApplicationTests {

	@Test
	void contextLoads() {
	}

}
